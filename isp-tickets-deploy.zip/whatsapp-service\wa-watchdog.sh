#!/bin/bash
# Meant to be run from a cPanel Cron Job every few minutes. If the WhatsApp
# bridge isn't running (crashed, server rebooted, host recycled the process),
# this restarts it. Silent when everything is already fine.

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PIDFILE="$DIR/whatsapp-service/wa.pid"

if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    exit 0
fi

"$DIR/whatsapp-service/wa-start.sh" >> "$DIR/whatsapp-service/wa-watchdog.log" 2>&1
