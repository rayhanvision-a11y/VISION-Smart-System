#!/bin/bash
# Starts whatsapp_server.cjs in the background and detaches it from the
# terminal session, so it keeps running after you close cPanel Terminal.
# Safe to re-run: if it's already running (per wa.pid), it does nothing.

set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$DIR"

PIDFILE="$DIR/whatsapp-service/wa.pid"
LOGFILE="$DIR/whatsapp-service/wa.log"

if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    echo "Already running (PID $(cat "$PIDFILE"))."
    exit 0
fi

# Pull WA_INTERNAL_SECRET out of the Laravel .env so both sides always match.
if [ -f "$DIR/.env" ]; then
    export WA_INTERNAL_SECRET="$(grep -m1 '^WA_INTERNAL_SECRET=' "$DIR/.env" | cut -d= -f2- | tr -d '"'"'"'\r')"
fi

nohup node "$DIR/whatsapp_server.cjs" >> "$LOGFILE" 2>&1 &
NEWPID=$!
disown "$NEWPID"
echo "$NEWPID" > "$PIDFILE"
echo "Started whatsapp_server.cjs (PID $NEWPID). Logs: $LOGFILE"
