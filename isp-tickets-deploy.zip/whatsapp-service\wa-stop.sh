#!/bin/bash
# Stops the whatsapp_server.cjs process started by wa-start.sh.

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PIDFILE="$DIR/whatsapp-service/wa.pid"

if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    kill "$(cat "$PIDFILE")"
    rm -f "$PIDFILE"
    echo "Stopped."
else
    echo "Not running (or PID file missing/stale)."
    rm -f "$PIDFILE"
fi
