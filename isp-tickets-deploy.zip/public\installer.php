<?php
/**
 * VISION Smart System - No-SSH cPanel Installer
 * ------------------------------------------------
 * Runs the setup steps that normally need `php artisan` on the command line
 * (migrate, storage link, cache) from the browser, for hosts with no
 * Terminal/SSH access.
 *
 * USE ONCE, THEN DELETE THIS FILE. It has no login and will run migrations
 * for anyone who visits the URL until you remove it.
 *
 * Visit: https://YOURDOMAIN/installer.php
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');

require __DIR__ . '/../vendor/autoload.php';

/** @var \Illuminate\Foundation\Application $app */
$app = require __DIR__ . '/../bootstrap/app.php';

/** @var \Illuminate\Contracts\Console\Kernel $kernel */
$kernel = $app->make(\Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

function runStep(string $label, callable $fn, array &$log): void
{
    $log[] = ['label' => $label, 'ok' => null, 'output' => ''];
    $i = array_key_last($log);
    try {
        $out = $fn();
        $log[$i]['ok'] = true;
        $log[$i]['output'] = is_string($out) ? $out : '';
    } catch (\Throwable $e) {
        $log[$i]['ok'] = false;
        $log[$i]['output'] = $e->getMessage();
    }
}

$log = [];
$ran = isset($_GET['run']) && $_GET['run'] === '1';

if ($ran) {
    // 1. App key (only if not already set)
    runStep('Generate APP_KEY (skipped if already set)', function () {
        if (!empty(env('APP_KEY'))) {
            return 'APP_KEY already set — skipped.';
        }
        \Illuminate\Support\Facades\Artisan::call('key:generate', ['--force' => true]);
        return \Illuminate\Support\Facades\Artisan::output();
    }, $log);

    // 2. Migrate
    runStep('Run database migrations', function () {
        \Illuminate\Support\Facades\Artisan::call('migrate', ['--force' => true]);
        return \Illuminate\Support\Facades\Artisan::output();
    }, $log);

    // 3. Storage link (fallback to copy if symlink() is disabled)
    runStep('Link storage/app/public -> public/storage', function () {
        $target = __DIR__ . '/storage';
        $source = __DIR__ . '/../storage/app/public';
        if (is_link($target) || is_dir($target)) {
            return 'public/storage already exists — skipped.';
        }
        if (function_exists('symlink') && @symlink($source, $target)) {
            return 'Symlink created.';
        }
        // Fallback: physical copy (won't auto-update with new files, but works without symlink permission)
        $copy = function ($src, $dst) use (&$copy) {
            if (!is_dir($dst)) mkdir($dst, 0755, true);
            foreach (scandir($src) as $item) {
                if ($item === '.' || $item === '..') continue;
                $s = $src . '/' . $item;
                $d = $dst . '/' . $item;
                is_dir($s) ? $copy($s, $d) : copy($s, $d);
            }
        };
        $copy($source, $target);
        return 'symlink() unavailable — copied files instead (re-run installer after future uploads to refresh).';
    }, $log);

    // 4. Cache config/routes/views for performance
    runStep('Cache config, routes, and views', function () {
        \Illuminate\Support\Facades\Artisan::call('config:cache');
        \Illuminate\Support\Facades\Artisan::call('route:cache');
        \Illuminate\Support\Facades\Artisan::call('view:cache');
        return 'Cached.';
    }, $log);

    // 5. Seed default users (only if users table is empty)
    runStep('Seed default users (only if users table is empty)', function () {
        $count = \Illuminate\Support\Facades\DB::table('users')->count();
        if ($count > 0) {
            return "users table already has {$count} row(s) — skipped seeding.";
        }
        \Illuminate\Support\Facades\Artisan::call('db:seed', ['--force' => true]);
        return \Illuminate\Support\Facades\Artisan::output();
    }, $log);
}

$allOk = $ran && !in_array(false, array_column($log, 'ok'), true);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>VISION Smart System - Installer</title>
<style>
  body { font-family: system-ui, sans-serif; background:#0f172a; color:#e2e8f0; margin:0; padding:2rem 1rem; }
  .wrap { max-width: 760px; margin: 0 auto; }
  h1 { font-size: 1.4rem; }
  .card { background:#1e293b; border:1px solid #334155; border-radius:12px; padding:1.25rem 1.5rem; margin-bottom:1rem; }
  .step { padding:.75rem 0; border-bottom:1px solid #334155; }
  .step:last-child { border-bottom:none; }
  .ok { color:#4ade80; font-weight:700; }
  .fail { color:#f87171; font-weight:700; }
  pre { background:#0f172a; padding:.75rem; border-radius:8px; overflow:auto; font-size:.8rem; white-space:pre-wrap; }
  a.btn { display:inline-block; background:#4f46e5; color:#fff; padding:.6rem 1.2rem; border-radius:8px; text-decoration:none; font-weight:600; }
  .warn { background:#450a0a; border:1px solid #991b1b; color:#fecaca; padding:1rem; border-radius:10px; }
</style>
</head>
<body>
<div class="wrap">
  <h1>VISION Smart System &mdash; Installer</h1>

  <div class="warn">
    <strong>Security:</strong> delete this file (<code>public/installer.php</code>) from the server as soon as setup succeeds.
  </div>

  <?php if (!$ran): ?>
    <div class="card">
      <p>This will run, in order: <code>key:generate</code> (if needed), <code>migrate --force</code>, create the
      <code>public/storage</code> link, cache config/routes/views, and seed default users
      (only if the <code>users</code> table is currently empty).</p>
      <p>Make sure your <code>.env</code> file is uploaded and the database credentials in it are correct before running this.</p>
      <a class="btn" href="?run=1">Run Setup Now</a>
    </div>
  <?php else: ?>
    <div class="card">
      <h2><?= $allOk ? '<span class="ok">All steps completed</span>' : '<span class="fail">Some steps failed — see details below</span>' ?></h2>
      <?php foreach ($log as $step): ?>
        <div class="step">
          <div><?= $step['ok'] ? '<span class="ok">✓</span>' : '<span class="fail">✗</span>' ?> <?= htmlspecialchars($step['label']) ?></div>
          <?php if ($step['output'] !== ''): ?><pre><?= htmlspecialchars($step['output']) ?></pre><?php endif; ?>
        </div>
      <?php endforeach; ?>
      <?php if ($allOk): ?>
        <p>Default seeded logins (only if seeding ran): <code>admin@isp.com</code>, <code>noc@isp.com</code>, <code>reseller@isp.com</code> — password <code>password</code> for all. <strong>Change these immediately.</strong></p>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</div>
</body>
</html>
